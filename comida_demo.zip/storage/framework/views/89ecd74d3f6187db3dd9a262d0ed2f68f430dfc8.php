 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit this Role</div>

                <div class="card-body">
                    <form action="<?php echo e(route('admin.role.update', $role->id)); ?>" method="post">
                        <?php echo csrf_field(); ?> <?php echo method_field('patch'); ?>
                        <div class="form-group">
                            <label for="role">Role Name</label>
                            <input type="text" value="<?php echo e($role->name); ?>" name="name" class="form-control" id="role">
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm">Change</button>
                        <a href="<?php echo e(route('admin.roles')); ?>" class="btn btn-danger btn-sm float-right">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/vendor/multiauth/roles/edit.blade.php ENDPATH**/ ?>