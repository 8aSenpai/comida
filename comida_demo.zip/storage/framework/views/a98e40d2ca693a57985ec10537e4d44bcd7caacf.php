<?php $__env->startSection('content'); ?>
  
<div class="container app_subcont disp_center sep">
	<!-- success -->
    <?php if($message = Session::get('success')): ?> 
    <div class="alert alert-success alert-block"> 
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong> 
    <?php endif; ?>
    <!-- success -->
	<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<div class="row"> 
		<div class="col-sm-12 col-md-6">
			<img class="prod_img" src="<?php echo e(asset('fotos_propiedades/'.$data->img)); ?>">
		</div>
		<div class="col-md-6 col-sm-12" style="text-align: left;">
			<div class="col-sm-12">
				<h2><?php echo e($data->comida_nombre); ?></h2>
			</div>
			<div class="col-sm-12">
				<h5 class="prod_desc"><?php echo e($data->desc); ?></h5>
			</div>
			<div class="col-sm-12">
				<h4 class="prod_prec"><b>$<?php echo e($data->comida_precio); ?></b></h4>
			</div>
			<div class="col-12"><p><b>Adicionales: </b></p></div>
			<div class="col-12 disp_center">
				<form action="<?php echo e(route('add_cart', $data->id_comida)); ?>">
					<?php $__currentLoopData = $adicionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			  	<div class="form-group prod_check">  
	  				<label class="prod_lab"><?php echo e($data2->ad_nombre); ?>  <b>Precio Total: $ <?php echo e($total= $data2->ad_precio + $data->comida_precio); ?> MXN </b>
					<input type="radio" value="<?php echo e($data2->id); ?>" name="radiadicionalo">
					<span class="checkmark"></span>
					</label> 
	  			</div>
	  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	   
	  				<button type="submit" class="btn btn-primary">Agregar</button>
				</form>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/producto.blade.php ENDPATH**/ ?>