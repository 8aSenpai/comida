 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(ucfirst(config('multiauth.prefix'))); ?> Bandeja de entrada</div>

                <div class="card-body mod_card_body"> 
                    <div class="row">
                        <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-md-4 col-sm-12">
                            <div class="ad_men_back">
                                <nav class="navbar-expand-md">
                                    <div class="container sub_mod_card_body"> 
                                        <button class="navbar-toggler ml-auto  custom-toggler" type="button" data-toggle="collapse" data-target="#side_menu" aria-controls="navbarSupportedContent"
                                                aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                                            <span class="navbar-toggler-icon"></span>
                                        </button>

                                        <div class="collapse navbar-collapse" id="side_menu">
                                            <!-- Left Side Of Navbar -->
                                            <div class="row">
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('admin_ordenes')); ?>"><button class="btn_home">Ordenes</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('admin_ordenes_anteriores')); ?>"><button class="btn_home">Ordenes Anteriores</button></a>
                                                </div>   
                                                <?php if (\Illuminate\Support\Facades\Blade::check('admin', 'super')): ?>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('admin.menu.cobros')); ?>"><button class="btn_home">Cobros</button></a>
                                                </div> 
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('Addprod')); ?>"><button class="btn_home">Agregar Productos</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('listprod')); ?>"><button class="btn_home">Ver/Editar Productos</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('desactivados')); ?>"><button class="btn_home">Productos No Disponibles</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('supcategoria')); ?>"><button class="btn_home">Categorias</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('adicionales')); ?>"><button class="btn_home">Adicionales a productos</button></a>
                                                </div>
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('admin.visuales')); ?>"><button class="btn_home">Visuales</button></a>
                                                </div>
                                                <?php endif; ?>
                                            </div> 
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-8 ad_cobro_men_fix">  
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                             <!--  <form class="bem-form"  action="<?php echo e(route('veradicional', $data->id_comida)); ?>" class="contact" method="post"> 
                                <?php echo e(csrf_field()); ?>    --> 
                            <div class="row" style="text-align: center; margin-bottom: 20px;"> 
                                <div class="col-md-6 col-sm-12">
                                    <div class="col-md-12 col-sm-12"> 
                                        <input type="text" name="nombre" class="form-control" value="<?php echo e($data->comida_nombre); ?>" disabled="true" id="role" required="true" style="font-weight: bold;"> 
                                    </div> 
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <a href="<?php echo e(route('veradicional', $data->id_comida)); ?>"><button type="submit" name="actualizar" class="btn btn-primary btn-sm">Agregar</button></a>
                                </div>   
                            </div>
                           <!--  </form>   -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </div>  
                    </div>   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/vendor/multiauth/adicionales.blade.php ENDPATH**/ ?>