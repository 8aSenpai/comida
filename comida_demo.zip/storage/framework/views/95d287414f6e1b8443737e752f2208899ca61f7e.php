<?php $__env->startSection('content'); ?>
 
<div class="container">
	<div class="row app_subcont disp_center sep"> 
		<?php
		$total = 0;
		?>
		<?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
		<!-- Item -->
		<div class="col-12 cart_div">
			<div class="row">
				<div class="col-md-4 col-sm-12">
					<img class="cart_img" src="<?php echo e(asset('fotos_propiedades/'.$data->img)); ?>">
				</div> 
				<div class="col-md-4 col-sm-12 cart_cent"> 
					<div class="col-12">
						<h3><?php echo e($data->comida_nombre); ?></h3>
						<p><b>Adicionales:</b></p>
						<p><?php echo e($data->ad_nombre); ?> $<?php echo e($data->ad_precio); ?></p>
					</div> 
					<div class="col-12">
						<h5 class="cart_prec"><b>Precio</b>: $<?php echo e($data->comida_precio + $data->ad_precio); ?> MXN</h5>
					</div>  
				</div>
				<div class="col-md-4 col-sm-12 cart_cent"> 
	                <a href="<?php echo e(route('descartar', $data->id )); ?>"><button type="submit" class="cart_btn btn btn-primary">
	                    <?php echo e(__('Descartar')); ?>

	                </button></a>
				</div> 
			</div>
		</div>	
		<?php
			$total = $total+$data->comida_precio+$data->ad_precio;
		?>
		<!-- Enditem -->  
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="container disp_center cart_conf">
	<form action="<?php echo e(route('confirm')); ?>">
	<div class="row">
		<?php echo csrf_field(); ?>  
			<div class="col-12 checkbox_container">
				<input class="inp-cbx" id="cbx" name="acepto" type="checkbox" style="display: none;"/>
				<label class="cbx" for="cbx"><span>
				<svg width="12px" height="10px" viewbox="0 0 12 10">
				<polyline points="1.5 6 4.5 9 10.5 1"></polyline>
				</svg></span><span>He leído y estoy de acuerdo con las <a href="#">Condiciones de Uso</a> de compra.</span></label>
			</div>
			<?php if($message = Session::get('fail')): ?>
			<div class="col-12 fail_alert">
 				<strong class=""><?php echo e($message); ?></strong>
			</div>
            <?php endif; ?>
		<div class="col-6">
			<h5>Total: <b>$<?php echo e($total); ?> MXN</b></h5>
		</div>		
		<div class="col-6">
			<button type="submit" class="btn btn-primary" value="confirm">
	            <?php echo e(__('Confirmar')); ?>

	        </button>
		</div>	 
	</div>
	</form>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/carrito.blade.php ENDPATH**/ ?>