<?php $__env->startSection('content'); ?>
  
<div class="container ord_cont disp_center sep">
	<div class="row ord_head">  
		<div class="col-6">
			<h3>Numero</h3>
		</div>
		<div class="col-6">
			<h3>Estado</h3>
		</div> 
	</div>


	<div class="row">  
		<?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $datal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-6">
			<h3>Orden #<?php echo e($datal->no_orden); ?></h3>
		</div>
		<div class="col-6 ord_status_cont">
			<h3><span class="ord_status_g">Lista</span></h3>
		</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div> 
	<div class="row">  
		<?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $datap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-6">
			<h3>Orden #<?php echo e($datap->no_orden); ?></h3>
		</div>

		<div class="col-6 ord_status_cont">
			<h3><span class="ord_status_r">Pendiente</span></h3>
		</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/ordenes.blade.php ENDPATH**/ ?>