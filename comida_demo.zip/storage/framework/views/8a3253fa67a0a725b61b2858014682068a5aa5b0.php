<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/sidebar.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid com_slogan">
	<?php $__currentLoopData = $visuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
     	<div class="col-md-12"> 
	     		<img class="slog_img"  src="<?php echo e(asset('fotos_propiedades/'.$mainlog->logo)); ?>"> 
     	</div>
     	<div class="col-12 slog_bor">
     		<div class="slog_tit_cont">
     			<h1 class="slog_tit"><?php echo e($mainlog->titulo); ?></h1> 
     		</div>  
     	</div>
     	<div class="col-12"> 
	     	<h2 class="slog_slog"><?php echo e($mainlog->slogan); ?></h2> 
     	</div> 
     </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="container"> 

	<!-- side -->
	<div id="mySidenav" class="sidenav">
		  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $datac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
		  <a href="<?php echo e($datac->nombre); ?>"><?php echo e($datac->nombre); ?></a> 
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<!-- Use any element to open the sidenav -->
	<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Categorias</span>

	<!-- side -->

	<div class="row disp_center" id="main">  
	<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		<!-- Item -->
		<div class="col-sm-12 col-md-3">
			<div class="disp_cont">
				<a href="<?php echo e(route('producto', $data->id_comida )); ?>">
				<div class="col-12">
					<img class="disp_img" src="<?php echo e(asset('fotos_propiedades/'.$data->img)); ?>">
				</div> 
				<div class="col-12">
					<h4 class="disp_tit">$<?php echo e($data->comida_precio); ?></h4>
				</div> 
				<div class="col-12">
					<h5 class="disp_prec"><?php echo e($data->comida_nombre); ?></h5>
				</div> 
				</a> 
			</div>
		</div>	
		<!-- Enditem -->    
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?> 
<script src="<?php echo e(asset('js/sidebar.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/welcome.blade.php ENDPATH**/ ?>