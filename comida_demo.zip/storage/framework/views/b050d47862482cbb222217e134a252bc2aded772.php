<?php $__env->startSection('content'); ?>
  
<div class="container app_subcont sep">
	<div class="row">
		<div class="col-12">
			<h1>Politicas de Privacidad.</h1>
		</div>
		<div class="col-12">
			<?php $__currentLoopData = $visuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $acerca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
			 <?php echo e($acerca->politicas_privacidad); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/politicas_privacidad.blade.php ENDPATH**/ ?>