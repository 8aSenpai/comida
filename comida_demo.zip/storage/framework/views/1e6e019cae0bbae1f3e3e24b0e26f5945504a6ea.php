<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__currentLoopData = $visuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($tit->titulo); ?></title>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/comcss.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>  
    <!-- Font awesome -->
    <script src="https://kit.fontawesome.com/6ec9eab5b1.js"></script>
</head>
<body> 
        <nav class="navbar fixed-top navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php $__currentLoopData = $visuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tit2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($tit->titulo); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto"> 
                        <li class="nav-item">
                            <a class="dropdown-item" href="<?php echo e(route('ordenes')); ?>" >
                                <?php echo e(__('Ordenes')); ?>

                            </a>
                        </li> 
                        <li class="nav-item">
                            <a class="dropdown-item" href="<?php echo e(route('carrito')); ?>" >
                            <?php if($contcarrito != 0): ?>
                            <span class="car_cont"><?php echo e($contcarrito); ?></span><i style="color: red !important;" class="fas fa-shopping-cart"></i>
                            <?php endif; ?>
                            <?php echo e(__('Carrito')); ?>

                            </a>
                        </li> 
                    </ul>
                </div>
            </div>
        </nav>
 
            <?php echo $__env->yieldContent('content'); ?>  
        <?php $__currentLoopData = $visuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <footer id="footer" class="footer bg-light ">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 my-auto h-100 text-center text-lg-left">
                    <ul class="list-inline mb-2">
                        <li class="list-inline-item"><a style="color: red !important;" href="<?php echo e(route('acerca.de')); ?>">Acerca de</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a style="color: red !important;" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a style="color: red !important;" href="<?php echo e(route('terminos.uso')); ?>">Terminos de Uso</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a style="color: red !important;" href="<?php echo e(route('politicas.privacidad')); ?>">Política de Privacidad</a></li>
                    </ul>
                    <p style="color: red !important;" class="text-muted small mb-4 mb-lg-0">© Copyright 2019 najeraasociados</p>
                </div>
                <div class="col-lg-6 my-auto h-100 text-center text-lg-right">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="<?php echo e($rex->facebook); ?>"><i style="color: red !important;" class="fab fa-facebook-square fa-2x"></i></a></li>
                        <li class="list-inline-item"><a href="<?php echo e($rex->twitter); ?>"><i style="color: red !important;" class="fab fa-twitter fa-2x"></i></a></li>
                        <li class="list-inline-item"><a href="<?php echo e($rex->instagram); ?>"><i style="color: red !important;" class="fab fa-instagram fa-2x"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>  
</body>
</html>
<?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/layouts/app.blade.php ENDPATH**/ ?>