 
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Ordenes Activas</div>
					<?php
                		$total = 0;
                	?>
                <div class="card-body"> 
                	<div class="row">
                	<?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                	<?php if($data->estado == 'preparando'): ?>
                	<!-- Orden -->
                	<div class="col-sm-12 col-md-4 ad_ord_cont_cont">
                		<div class="ad_ord_cont_pend">
	                		<div class="col-12 ad_ord_tit">
	                			<b>Fecha: </b><?php echo e($data->fecha); ?>

	                		</div>
	                		<div class="col-12">
	                			Orden ID <B>#<?php echo e($data->no_orden); ?></B>
	                		</div>
	                		<div class="col-12">
	                			<b>Nombre:</b> Nombre Usuario  
	                 		</div> 
	                		<div class="col-12">
	                			<b>Telefono:</b> Telefono Usuario
	                 		</div> 
	                 		<div class="col-12">
	                 			<b>Detalles:</b>
	                 		</div> 
	                 		<?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
	                 			<?php if($data2->no_orden == $data->no_orden): ?>
	                 			<div class="col-12">
	                 				<li>
	                 					<?php echo e($data2->comida_nombre); ?> + <?php echo e($data2->ad_nombre); ?>

	                 				</li>
	                 			</div>
	                 			<?php
			                		$total += $data2->comida_precio + $data2->ad_precio
			                	?>
	 							<?php endif; ?>   
	                 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                 		<div class="col-12">
	 							<b>Total: $<?php echo e($total); ?>MXN</b>
	 						</div>

	 						<div class="row disp_center"> 
		 						<div class="col-4">
		 							<a href="<?php echo e(route('ad_orden_lista', $data->no_orden)); ?>"><button class="ad_ord_btn">Listo</button></a>
		 						</div>
		 						<div class="col-4">
		 							<a href="<?php echo e(route('ad_orden_espera', $data->no_orden)); ?>"><button class="ad_ord_btn">Procesando</button></a>
		 						</div>
		 						<div class="col-4">
		 							<a href="<?php echo e(route('ad_orden_cancel', $data->id_usuario)); ?>" onclick="myFunction()"><button id="ord_cancel" class="ad_ord_btn" >Cancelar</button></a>
	 							</div>
	 						</div>

	 					</div>
                	</div>
                	<?php
                		 $total = 0;
                	?>
                	<!-- Orden -->
                	<?php endif; ?>
                	<?php if($data->estado == 'pendiente'): ?>
                	<!-- Orden -->
                	<div class="col-sm-12 col-md-4 ad_ord_cont_cont">
                		<div class="ad_ord_cont_esp">
	                		<div class="col-12 ad_ord_tit">
	                			<b>Fecha: </b><?php echo e($data->fecha); ?>

	                		</div>
	                		<div class="col-12">
	                			Orden ID <B>#<?php echo e($data->no_orden); ?></B>
	                		</div>
	                		<div class="col-12">
	                			<b>Nombre:</b> Nombre Usuario  
	                 		</div> 
	                		<div class="col-12">
	                			<b>Telefono:</b> Telefono Usuario
	                 		</div> 
	                 		<div class="col-12">
	                 			<b>Detalles:</b>
	                 		</div> 
	                 		<?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	 								  
	                 			<?php if($data2->no_orden == $data->no_orden): ?>
	                 			<div class="col-12">
	                 				<li>
	                 					<?php echo e($data2->comida_nombre); ?> + <?php echo e($data2->ad_nombre); ?>

	                 				</li>
	                 			</div>
	                 			<?php
			                		$total += $data2->comida_precio + $data2->ad_precio
			                	?>
	 							<?php endif; ?>   

	                 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                 		<div class="col-12">
	 							<b>Total: $<?php echo e($total); ?> MXN</b>
	 						</div>

	 						<div class="row disp_center"> 
		 						<div class="col-4 mt-auto">
		 							<a href="<?php echo e(route('ad_orden_lista', $data->no_orden)); ?>"><button class="ad_ord_btn">Listo</button></a>
		 						</div>
		 						<div class="col-4 mt-auto">
		 							<a href="<?php echo e(route('ad_orden_espera', $data->no_orden)); ?>"><button class="ad_ord_btn">Procesando</button></a>
		 						</div>
		 						<div class="col-4 mt-auto">
		 							<a href="<?php echo e(route('ad_orden_cancel', $data->id_usuario)); ?>" onclick="myFunction()"><button id="ord_cancel" class="ad_ord_btn" >Cancelar</button></a>
	 							</div>
	 						</div>
	 					</div>
                	</div>
                	<?php
                		 $total = 0;
                	?>
                	<!-- Orden -->
                	<?php endif; ?>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</div>
                	<div class="row disp_center"> 
	 					<div class="col-12">
		 					<a href="<?php echo e(route('admin.home')); ?>"><button class="back_btn">Atras</button></a>
		 				</div>
                	</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
function myFunction() {
  if (confirm('Si cancelas la orden, no la podras recuperar')) {
      var url = $(this).attr('href');
      $('#content').load(url);
    }
  else{
      event.preventDefault();
  }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\comida_demo\resources\views/vendor/multiauth/admin_ordenes_activas.blade.php ENDPATH**/ ?>